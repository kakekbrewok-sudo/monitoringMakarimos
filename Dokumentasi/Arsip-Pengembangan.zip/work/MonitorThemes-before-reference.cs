using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.Windows.Forms;

enum MonitorTheme { DotBlack, DotWhite, Dial, Segment }

static class ThemeCatalog
{
    public static readonly string[] Labels = { "Dot Hitam (default)", "Dot Putih", "Dial · jam analog", "Segment · LCD" };
    public static readonly string[] Keys = { "dot-black", "dot-white", "dial", "segment" };
    public static MonitorTheme Parse(string key)
    {
        int index = Array.IndexOf(Keys, key);
        return index < 0 ? MonitorTheme.DotBlack : (MonitorTheme)index;
    }
}

sealed partial class MonitorWindow
{
    MonitorTheme theme = MonitorTheme.DotBlack;
    ToolStripMenuItem themeMenu;
    Color rule = Color.FromArgb(48, 48, 48), frame = Color.FromArgb(57, 57, 57), track = Color.FromArgb(48, 48, 48);
    readonly Font dialTime = new Font("Georgia", 26f, FontStyle.Regular);
    readonly Font dialName = new Font("Georgia", 13.5f, FontStyle.Regular);
    readonly Font mono = new Font("Consolas", 9f, FontStyle.Regular);
    readonly Font monoTitle = new Font("Consolas", 12f, FontStyle.Bold);
    readonly Font monoTime = new Font("Consolas", 20f, FontStyle.Regular);

    void SetTheme(MonitorTheme selected, bool persist)
    {
        theme = selected;
        switch (theme)
        {
            case MonitorTheme.DotWhite:
                BackColor = Color.FromArgb(245, 245, 240); ForeColor = Color.FromArgb(28, 28, 27);
                accent = Color.FromArgb(198, 43, 44); muted = Color.FromArgb(102, 102, 98);
                rule = frame = Color.FromArgb(210, 210, 203); track = Color.FromArgb(220, 220, 212);
                break;
            case MonitorTheme.Dial:
                BackColor = Color.FromArgb(242, 236, 223); ForeColor = Color.FromArgb(43, 43, 35);
                accent = Color.FromArgb(176, 57, 35); muted = Color.FromArgb(111, 105, 89);
                rule = frame = Color.FromArgb(202, 193, 173); track = Color.FromArgb(222, 213, 193);
                break;
            case MonitorTheme.Segment:
                BackColor = Color.FromArgb(22, 35, 29); ForeColor = Color.FromArgb(218, 230, 178);
                accent = Color.FromArgb(241, 119, 95); muted = Color.FromArgb(152, 172, 140);
                rule = frame = Color.FromArgb(64, 82, 61); track = Color.FromArgb(45, 63, 47);
                break;
            default:
                BackColor = Color.FromArgb(15, 15, 15); ForeColor = Color.FromArgb(238, 238, 234);
                accent = Color.FromArgb(239, 52, 55); muted = Color.FromArgb(154, 154, 154);
                rule = track = Color.FromArgb(48, 48, 48); frame = Color.FromArgb(57, 57, 57);
                break;
        }
        // All four layouts share the same bounds. A theme change only repaints;
        // no handle recreation, activation, timer, sensor reload or menu closing.
        if (persist) SaveSettings();
        Invalidate();
    }

    void PaintDial(Graphics g, DateTime now, int width)
    {
        DrawText(g, "MINI MONITOR", heading, ForeColor, new Rectangle(18, 8, 170, 21));
        DrawText(g, "DIAL", small, muted, new Rectangle(width - 104, 8, 86, 21), true);
        DrawDial(g, now, 76, 88, 49);
        DrawText(g, now.ToString("HH:mm"), dialTime, ForeColor, new Rectangle(137, 42, width - 152, 47));
        DrawText(g, now.ToString("ss") + "  DETIK", mono, accent, new Rectangle(144, 87, width - 162, 19));
        DrawText(g, now.ToString("ddd, dd MMM", CultureInfo.GetCultureInfo("id-ID")).ToUpperInvariant(), small, muted, new Rectangle(144, 108, width - 162, 21));
        Divider(g, 149, width);
        AppSession current = activity.Selected;
        bool reminder = current != null && current.ReminderDue;
        DrawText(g, ActivityLabel(current), small, muted, new Rectangle(18, 157, width - 36, 16));
        DrawText(g, current == null ? "Buka game atau aplikasi" : current.App.Name, dialName, ForeColor, new Rectangle(18, 175, width - 36, 27));
        int half = (width - 48) / 2;
        DrawText(g, "WAKTU AKTIF", small, muted, new Rectangle(18, 209, half, 15));
        DrawText(g, "SEJAK DIBUKA", small, muted, new Rectangle(30 + half, 209, half, 15));
        string active = ActivityTracker.Duration(current == null ? 0 : current.ActiveSeconds);
        double opened = current == null ? -1 : ActivityTracker.OpenDuration(current.App, DateTime.UtcNow);
        DrawText(g, active, compact, reminder ? accent : ForeColor, new Rectangle(18, 228, half, 24));
        DrawText(g, opened < 0 ? "—" : ActivityTracker.Duration(opened), compact, ForeColor, new Rectangle(30 + half, 228, half, 24));
        DrawText(g, reminder ? "60 MENIT+ / WAKTUNYA ISTIRAHAT" : "PENGINGAT ISTIRAHAT / 60 MENIT", small, reminder ? accent : muted, new Rectangle(18, 256, width - 36, 18));
        ProgressRule(g, current, reminder, width, 278, 2);
        DialMetric(g, "RAM", data.MemoryValid ? data.Load + "%" : "—", 284, width);
        DialMetric(g, "CPU", data.Cpu.UsageAndTemperature, 303, width);
        DialMetric(g, "GPU", data.Gpu.UsageAndTemperature, 322, width);
    }

    void DialMetric(Graphics g, string name, string reading, int y, int width)
    {
        DrawText(g, name, small, muted, new Rectangle(18, y, 56, 18));
        DrawText(g, reading, heading, ForeColor, new Rectangle(80, y, width - 98, 18), true);
    }

    string ActivityLabel(AppSession current)
    {
        return activity.IsActive ? "APLIKASI AKTIF" : current == null ? "MENUNGGU APLIKASI" : "JEDA / DI LATAR BELAKANG";
    }

    void DrawDial(Graphics g, DateTime now, float cx, float cy, float radius)
    {
        GraphicsState saved = g.Save();
        g.ScaleTransform(scale, scale); g.SmoothingMode = SmoothingMode.AntiAlias;
        using (var edge = new Pen(rule, 1)) g.DrawEllipse(edge, cx - radius, cy - radius, radius * 2, radius * 2);
        using (var minor = new Pen(rule, 1))
        using (var major = new Pen(ForeColor, 1.5f))
        {
            for (int tick = 0; tick < 60; tick++)
            {
                double angle = tick * Math.PI / 30 - Math.PI / 2;
                float outer = radius - 4, inner = outer - (tick % 5 == 0 ? 6 : 2);
                g.DrawLine(tick % 5 == 0 ? major : minor,
                    cx + (float)Math.Cos(angle) * inner, cy + (float)Math.Sin(angle) * inner,
                    cx + (float)Math.Cos(angle) * outer, cy + (float)Math.Sin(angle) * outer);
            }
        }
        Hand(g, cx, cy, (now.Hour % 12 + now.Minute / 60.0) * Math.PI / 6, 24, 3.2f, ForeColor);
        Hand(g, cx, cy, (now.Minute + now.Second / 60.0) * Math.PI / 30, 35, 2.2f, ForeColor);
        Hand(g, cx, cy, now.Second * Math.PI / 30, 39, 1.1f, accent);
        using (var center = new SolidBrush(accent)) g.FillEllipse(center, cx - 2.5f, cy - 2.5f, 5, 5);
        g.Restore(saved);
    }

    static void Hand(Graphics g, float x, float y, double angle, float length, float thickness, Color ink)
    {
        using (var pen = new Pen(ink, thickness))
        {
            pen.StartCap = pen.EndCap = LineCap.Round;
            g.DrawLine(pen, x, y, x + (float)Math.Sin(angle) * length, y - (float)Math.Cos(angle) * length);
        }
    }

    void PaintSegment(Graphics g, DateTime now, int width)
    {
        DrawText(g, "MINI MONITOR", mono, ForeColor, new Rectangle(18, 9, 155, 21));
        DrawText(g, "SEGMENT", mono, muted, new Rectangle(width - 106, 9, 88, 21), true);
        SegmentClock.Draw(g, now.ToString("HH:mm"), 18, 43, 62, ForeColor, track, scale);
        SegmentClock.Draw(g, now.ToString("ss"), width - 54, 77, 26, ForeColor, track, scale);
        DrawText(g, now.ToString("ddd, dd MMM yyyy", CultureInfo.GetCultureInfo("id-ID")).ToUpperInvariant(), mono, muted, new Rectangle(18, 113, width - 36, 19));
        Divider(g, 138, width);
        AppSession current = activity.Selected;
        bool reminder = current != null && current.ReminderDue;
        DrawText(g, ActivityLabel(current), mono, muted, new Rectangle(18, 147, width - 36, 18));
        DrawText(g, current == null ? "Buka game atau aplikasi" : current.App.Name, monoTitle, ForeColor, new Rectangle(18, 168, width - 36, 25));
        string active = ActivityTracker.Duration(current == null ? 0 : current.ActiveSeconds);
        DrawText(g, active, monoTime, reminder ? accent : ForeColor, new Rectangle(14, 195, width - 80, 38));
        DrawText(g, "AKTIF", mono, muted, new Rectangle(width - 65, 203, 47, 25), true);
        double opened = current == null ? -1 : ActivityTracker.OpenDuration(current.App, DateTime.UtcNow);
        DrawText(g, "DIBUKA  " + (opened < 0 ? "—" : ActivityTracker.Duration(opened)), mono, muted, new Rectangle(18, 234, width - 36, 21));
        ProgressRule(g, current, reminder, width, 261, 4);
        DrawText(g, reminder ? "60 MENIT+ / WAKTUNYA ISTIRAHAT" : "PENGINGAT ISTIRAHAT / 60 MENIT", small, reminder ? accent : muted, new Rectangle(18, 271, width - 36, 18));
        int ramWidth = 48, col = (width - 36 - ramWidth - 20) / 2;
        Metric(g, "RAM", data.MemoryValid ? data.Load + "%" : "—", 18, ramWidth, false);
        Metric(g, "CPU", data.Cpu.UsageAndTemperature, 18 + ramWidth + 10, col, true);
        Metric(g, "GPU", data.Gpu.UsageAndTemperature, 18 + ramWidth + 20 + col, col, true);
        LoadBar(g, data.MemoryValid ? (float?)data.Load : null, 18, 334, ramWidth);
        LoadBar(g, data.Cpu.Load, 18 + ramWidth + 10, 334, col);
        LoadBar(g, data.Gpu.Load, 18 + ramWidth + 20 + col, 334, col);
    }

    void ProgressRule(Graphics g, AppSession current, bool reminder, int width, int y, int height)
    {
        using (var background = new SolidBrush(track)) g.FillRectangle(background, S(18), S(y), S(width - 36), S(height));
        double progress = current == null ? 0 : current.ReminderProgress;
        if (progress > 0) using (var fill = new SolidBrush(reminder ? accent : ForeColor))
            g.FillRectangle(fill, S(18), S(y), S((int)((width - 36) * progress)), S(height));
    }

    void LoadBar(Graphics g, float? load, int x, int y, int width)
    {
        using (var background = new SolidBrush(track)) g.FillRectangle(background, S(x), S(y), S(width), S(2));
        if (load.HasValue && load > 0) using (var fill = new SolidBrush(muted))
            g.FillRectangle(fill, S(x), S(y), S((int)(width * Math.Min(100, load.Value) / 100)), S(2));
    }

    void DisposeThemeFonts()
    {
        dialTime.Dispose(); dialName.Dispose(); mono.Dispose(); monoTitle.Dispose(); monoTime.Dispose();
    }
}

static class SegmentClock
{
    static readonly int[] Masks = { 0x3f, 0x06, 0x5b, 0x4f, 0x66, 0x6d, 0x7d, 0x07, 0x7f, 0x6f };
    public static void Draw(Graphics g, string text, float x, float y, float height, Color ink, Color dim, float scale)
    {
        GraphicsState saved = g.Save(); g.ScaleTransform(scale, scale); g.SmoothingMode = SmoothingMode.AntiAlias;
        float w = height * .52f, t = height * .075f, half = height / 2;
        using (var on = new SolidBrush(ink))
        using (var off = new SolidBrush(dim))
        {
            foreach (char c in text)
            {
                if (c == ':')
                {
                    g.FillRectangle(on, x + t, y + height * .31f, t, t);
                    g.FillRectangle(on, x + t, y + height * .68f, t, t);
                    x += height * .25f; continue;
                }
                if (c < '0' || c > '9') continue;
                int mask = Masks[c - '0'];
                Horizontal(g, (mask & 1) != 0 ? on : off, x + t, y, w - 2 * t, t);
                Vertical(g, (mask & 2) != 0 ? on : off, x + w - t, y + t, half - 1.5f * t, t);
                Vertical(g, (mask & 4) != 0 ? on : off, x + w - t, y + half + t / 2, half - 1.5f * t, t);
                Horizontal(g, (mask & 8) != 0 ? on : off, x + t, y + height - t, w - 2 * t, t);
                Vertical(g, (mask & 16) != 0 ? on : off, x, y + half + t / 2, half - 1.5f * t, t);
                Vertical(g, (mask & 32) != 0 ? on : off, x, y + t, half - 1.5f * t, t);
                Horizontal(g, (mask & 64) != 0 ? on : off, x + t, y + half - t / 2, w - 2 * t, t);
                x += height * .70f;
            }
        }
        g.Restore(saved);
    }
    static void Horizontal(Graphics g, Brush b, float x, float y, float w, float t)
    {
        g.FillPolygon(b, new[] { new PointF(x, y + t / 2), new PointF(x + t / 2, y), new PointF(x + w - t / 2, y), new PointF(x + w, y + t / 2), new PointF(x + w - t / 2, y + t), new PointF(x + t / 2, y + t) });
    }
    static void Vertical(Graphics g, Brush b, float x, float y, float h, float t)
    {
        g.FillPolygon(b, new[] { new PointF(x + t / 2, y), new PointF(x + t, y + t / 2), new PointF(x + t, y + h - t / 2), new PointF(x + t / 2, y + h), new PointF(x, y + h - t / 2), new PointF(x, y + t / 2) });
    }
}
