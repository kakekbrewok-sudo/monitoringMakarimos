$ErrorActionPreference='Stop'
$a=[Reflection.Assembly]::LoadFrom((Resolve-Path 'outputs\MiniMonitor\sensors\LibreHardwareMonitorLib.dll'))
$c=New-Object LibreHardwareMonitor.Hardware.Computer
$c.IsCpuEnabled=$true
$c.IsGpuEnabled=$true
$c.IsStorageEnabled=$true
try { $c.Open(); foreach($h in $c.Hardware){$h.Update(); Write-Output ($h.HardwareType.ToString()+' | '+$h.Name); $h.Sensors | Where-Object SensorType -eq Temperature | Select-Object Name,Value | Format-Table} } finally {$c.Close()}
