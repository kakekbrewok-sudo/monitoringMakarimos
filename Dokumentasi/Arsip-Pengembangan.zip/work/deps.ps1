$root='C:\Users\Makarim\Documents\Codex\2026-10-11\co\outputs\MiniMonitor\sensors'
$seen=@{}
function Read-Dependency([string]$name) {
  if($seen.ContainsKey($name)){return}
  $path=Join-Path $root ($name+'.dll')
  if(!(Test-Path -LiteralPath $path)){return}
  $seen[$name]=$true
  $asm=[Reflection.Assembly]::ReflectionOnlyLoadFrom($path)
  foreach($reference in $asm.GetReferencedAssemblies()){Read-Dependency $reference.Name}
}
Read-Dependency 'LibreHardwareMonitorLib'
$seen.Keys | Sort-Object
