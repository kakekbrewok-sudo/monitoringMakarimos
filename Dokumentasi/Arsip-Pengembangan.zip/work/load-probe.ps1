$ErrorActionPreference='Stop'
[Reflection.Assembly]::LoadFrom('C:\Users\Makarim\Documents\Codex\2026-10-11\co\outputs\MiniMonitor\sensors\LibreHardwareMonitorLib.dll') | Out-Null
$c=New-Object LibreHardwareMonitor.Hardware.Computer
$c.IsCpuEnabled=$true
$c.IsGpuEnabled=$true
try {
  $c.Open()
  foreach($h in $c.Hardware){$h.Update()}
  Start-Sleep -Seconds 2
  foreach($h in $c.Hardware){$h.Update(); Write-Output $h.Name; $h.Sensors | Where-Object {$_.SensorType -eq 'Load'} | Select-Object Name,Value | Format-Table}
} finally {$c.Close()}
