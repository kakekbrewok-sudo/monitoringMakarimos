using System;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Reflection;
using System.Collections;
using System.IO;
using System.Threading.Tasks;
using System.Diagnostics;

class MiniMonitor : Form {
 [StructLayout(LayoutKind.Sequential)] struct Memory { public uint length,load; public ulong total,available,page,availPage,virt,availVirt,extended; }
 [DllImport("kernel32.dll")] static extern bool GlobalMemoryStatusEx(ref Memory m);
 Label ram=new Label(),cpu=new Label(),gpu=new Label(),status=new Label();
 System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer(); object computer; bool busy; string sensorError;
 static object Get(object o,string p){return o.GetType().GetProperty(p).GetValue(o,null);}
 static void Set(object o,string p,object v){var x=o.GetType().GetProperty(p);if(x!=null)x.SetValue(o,v,null);}
 MiniMonitor(){
  Text="Mini Monitor";ClientSize=new Size(350,255);FormBorderStyle=FormBorderStyle.FixedSingle;MaximizeBox=false;
  BackColor=Color.FromArgb(23,27,34);ForeColor=Color.White;Font=new Font("Segoe UI",10);StartPosition=FormStartPosition.CenterScreen;
  var title=new Label{Text="MINI MONITOR",Location=new Point(20,16),AutoSize=true,ForeColor=Color.LightSkyBlue};Controls.Add(title);
  Label[] rows={ram,cpu,gpu};for(int i=0;i<rows.Length;i++){rows[i].Bounds=new Rectangle(20,53+i*47,315,40);rows[i].Font=new Font("Segoe UI",14);Controls.Add(rows[i]);}
  ram.Text="RAM   Membaca...";cpu.Text="CPU   Membaca...";gpu.Text="GPU   Membaca...";
  var pin=new CheckBox{Text="Selalu di atas",Location=new Point(20,199),AutoSize=true};pin.CheckedChanged+=(s,e)=>TopMost=pin.Checked;Controls.Add(pin);
  status.Bounds=new Rectangle(20,229,320,22);status.Font=new Font("Segoe UI",8);status.ForeColor=Color.Silver;Controls.Add(status);
  timer.Interval=3000;timer.Tick+=async(s,e)=>await RefreshData();Shown+=async(s,e)=>{await RefreshData();timer.Start();};
  FormClosed+=(s,e)=>{timer.Stop();timer.Dispose();if(!busy&&computer!=null)try{computer.GetType().GetMethod("Close").Invoke(computer,null);}catch{}};
 }
 void Init(){
  if(computer!=null||sensorError!=null)return;
  try{var asm=Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"sensors","LibreHardwareMonitorLib.dll"));computer=Activator.CreateInstance(asm.GetType("LibreHardwareMonitor.Hardware.Computer",true));Set(computer,"IsCpuEnabled",true);Set(computer,"IsGpuEnabled",true);computer.GetType().GetMethod("Open").Invoke(computer,null);}
  catch{sensorError="Sensor CPU: perlu library / akses administrator";computer=null;}
 }
 void Scan(object h,ref float? ct,ref float? gt){
  h.GetType().GetMethod("Update").Invoke(h,null);string kind=Get(h,"HardwareType").ToString();
  foreach(object s in (IEnumerable)Get(h,"Sensors")){if(Get(s,"SensorType").ToString()!="Temperature")continue;object v=Get(s,"Value");if(v==null)continue;float n=Convert.ToSingle(v);if(float.IsNaN(n)||n<=0||n>150)continue;
   if(kind=="Cpu")ct=ct.HasValue?Math.Max(ct.Value,n):n;
   if(kind.StartsWith("Gpu"))gt=gt.HasValue?Math.Max(gt.Value,n):n;
  }
  foreach(object sub in (IEnumerable)Get(h,"SubHardware"))Scan(sub,ref ct,ref gt);
 }
 async Task RefreshData(){
  if(busy)return;busy=true;
  try{var result=await Task.Run(()=>{
   Memory m=new Memory();m.length=(uint)Marshal.SizeOf(typeof(Memory));bool ok=GlobalMemoryStatusEx(ref m);float? ct=null,gt=null;Init();
   if(computer!=null)try{foreach(object h in (IEnumerable)Get(computer,"Hardware"))Scan(h,ref ct,ref gt);}catch{sensorError="Sensor belum bisa dibaca";}
   if(!gt.HasValue)try{using(var p=new Process()){p.StartInfo=new ProcessStartInfo("nvidia-smi.exe","--query-gpu=temperature.gpu --format=csv,noheader,nounits"){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true};p.Start();if(p.WaitForExit(1500)){foreach(string line in p.StandardOutput.ReadToEnd().Split('\n')){float v;if(float.TryParse(line.Trim(),out v)&&v>0&&v<150)gt=gt.HasValue?Math.Max(gt.Value,v):v;}}else p.Kill();}}catch{}
   return new string[]{ok?String.Format("RAM   {0:0.0} / {1:0.0} GB  ({2}%)",(m.total-m.available)/1073741824.0,m.total/1073741824.0,m.load):"RAM   Tidak tersedia", "CPU   "+(ct.HasValue?ct.Value.ToString("0")+" °C":"Tidak tersedia"),"GPU   "+(gt.HasValue?gt.Value.ToString("0")+" °C":"Tidak tersedia"),ct.HasValue?"Update 3 detik | suhu tertinggi sensor":sensorError??"Suhu CPU tidak tersedia pada perangkat ini"};
  });if(!IsDisposed){ram.Text=result[0];cpu.Text=result[1];gpu.Text=result[2];status.Text=result[3];}}
  finally{busy=false;if(IsDisposed&&computer!=null)try{computer.GetType().GetMethod("Close").Invoke(computer,null);}catch{}}
 }
 [STAThread] static void Main(){Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new MiniMonitor());}
}
