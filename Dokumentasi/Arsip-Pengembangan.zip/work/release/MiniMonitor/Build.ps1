param([string]$OutputPath = 'MiniMonitor.exe')
$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
& $compiler /nologo /target:winexe /platform:x64 /optimize+ "/out:$OutputPath" /win32manifest:MiniMonitor.manifest /reference:System.Windows.Forms.dll /reference:System.Drawing.dll /reference:Microsoft.CSharp.dll /reference:sensors\LibreHardwareMonitorLib.dll MonitorV2.cs ActivityTracker.cs DotClock.cs StartupIntegration.cs
if ($LASTEXITCODE -ne 0) { throw 'Build gagal.' }
