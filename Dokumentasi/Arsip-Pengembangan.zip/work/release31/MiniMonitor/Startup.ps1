param(
    [ValidateSet('Install','Update','Enable','Disable')][string]$Mode = 'Install',
    [string]$PreviousExecutable = '',
    [string]$ResultPath = ''
)
$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $launchArgs = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', ('"{0}"' -f $PSCommandPath), '-Mode', $Mode)
    if ($PreviousExecutable) { $launchArgs += @('-PreviousExecutable', ('"{0}"' -f $PreviousExecutable)) }
    if ($ResultPath) { $launchArgs += @('-ResultPath', ('"{0}"' -f $ResultPath)) }
    Start-Process powershell.exe -ArgumentList $launchArgs -Verb RunAs -WindowStyle Hidden
    exit
}

$taskName = 'MiniMonitor-' + $identity.User.Value
$installRoot = [IO.Path]::GetFullPath((Join-Path $env:ProgramFiles 'MiniMonitor'))
$expectedRoot = [IO.Path]::GetFullPath($env:ProgramFiles).TrimEnd('\') + '\MiniMonitor'
if ($installRoot -ne $expectedRoot) { throw 'Unexpected installation target.' }
$installedExe = Join-Path $installRoot 'MiniMonitor.exe'
$userData = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'MiniMonitor'
if (-not $ResultPath) { $ResultPath = Join-Path $userData 'startup-result.txt' }

try {
    New-Item -ItemType Directory -Force -Path $userData | Out-Null
    if ($Mode -eq 'Disable') {
        Disable-ScheduledTask -TaskName $taskName | Out-Null
        "Startup disabled: $taskName" | Set-Content -LiteralPath $ResultPath
        exit
    }
    if ($Mode -eq 'Enable') {
        Enable-ScheduledTask -TaskName $taskName | Out-Null
        "Startup enabled: $taskName" | Set-Content -LiteralPath $ResultPath
        exit
    }

    $sourceExe = Join-Path $PSScriptRoot 'MiniMonitor.exe'
    if (-not (Test-Path -LiteralPath $sourceExe)) { throw 'Ekstrak seluruh ZIP sebelum memasang.' }
    $allowedExecutables = @([IO.Path]::GetFullPath($sourceExe), $installedExe)
    if ($PreviousExecutable) { $allowedExecutables += [IO.Path]::GetFullPath($PreviousExecutable) }
    foreach ($process in @(Get-Process -Name MiniMonitor -ErrorAction SilentlyContinue)) {
        $processPath = $process.MainModule.FileName
        if ($allowedExecutables -contains $processPath) {
            $null = $process.CloseMainWindow()
            if (-not $process.WaitForExit(8000)) {
                # Only replace our exact known executable; no other applications.
                Stop-Process -Id $process.Id
                $process.WaitForExit(5000) | Out-Null
            }
        }
    }
    New-Item -ItemType Directory -Force -Path $installRoot | Out-Null
    if ([IO.Path]::GetFullPath($PSScriptRoot) -ne $installRoot) {
        Get-ChildItem -LiteralPath $PSScriptRoot | Where-Object { $_.Name -ne 'MiniMonitor.settings' } | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination $installRoot -Recurse -Force
        }
    }
    $localSettings = Join-Path $userData 'MiniMonitor.settings'
    $oldSettings = Join-Path $PSScriptRoot 'MiniMonitor.settings'
    if ($PreviousExecutable) { $oldSettings = Join-Path ([IO.Path]::GetDirectoryName($PreviousExecutable)) 'MiniMonitor.settings' }
    if (-not (Test-Path -LiteralPath $localSettings) -and (Test-Path -LiteralPath $oldSettings)) {
        Copy-Item -LiteralPath $oldSettings -Destination $localSettings
    }

    $existingTask = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if ($Mode -eq 'Update' -and $existingTask) {
        # Preserve the user's startup toggle, window/overlay mode and position.
        Start-Process -FilePath $installedExe -ArgumentList '--startup' -WindowStyle Normal
        @("Updated: $installedExe", "Task: $taskName", "Enabled: $($existingTask.Settings.Enabled)", 'Startup configuration and user settings preserved.') | Set-Content -LiteralPath $ResultPath
        exit
    }
    $action = New-ScheduledTaskAction -Execute $installedExe -Argument '--startup --overlay' -WorkingDirectory $installRoot
    $trigger = New-ScheduledTaskTrigger -AtLogOn -User $identity.Name
    $taskPrincipal = New-ScheduledTaskPrincipal -UserId $identity.Name -LogonType Interactive -RunLevel Highest
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $taskPrincipal -Settings $settings -Description 'Mini Monitor: clock, foreground application duration, RAM and temperatures. Starts at user login.' -Force | Out-Null
    Start-ScheduledTask -TaskName $taskName
    $task = Get-ScheduledTask -TaskName $taskName
    @("Installed: $installedExe", "Task: $taskName", "User: $($task.Principal.UserId)", "RunLevel: $($task.Principal.RunLevel)", "LogonType: $($task.Principal.LogonType)", "Enabled: $($task.Settings.Enabled)", "Arguments: $($task.Actions.Arguments)", "Trigger: $($task.Triggers.CimClass.CimClassName)") | Set-Content -LiteralPath $ResultPath
} catch {
    "ERROR: $($_.Exception.Message)" | Set-Content -LiteralPath $ResultPath
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show($_.Exception.Message, 'Mini Monitor - pemasangan belum selesai') | Out-Null
    exit 1
}
