$a=[Reflection.Assembly]::LoadFrom((Resolve-Path 'outputs\MiniMonitor\sensors\LibreHardwareMonitorLib.dll'))
$c=New-Object LibreHardwareMonitor.Hardware.Computer
$c.IsCpuEnabled=$true
$c.IsGpuEnabled=$true
try { $c.Open(); foreach($h in $c.Hardware){$h.Update(); $h.Sensors | Where-Object SensorType -eq Temperature | Select-Object Name,Value} } finally {$c.Close()}
$p=Start-Process (Resolve-Path 'outputs\MiniMonitor\MiniMonitor.exe') -WindowStyle Hidden -PassThru
Start-Sleep -Seconds 8
$p.Refresh()
$p | Select-Object HasExited,WorkingSet64,Responding
if(!$p.HasExited){$null=$p.CloseMainWindow()}
