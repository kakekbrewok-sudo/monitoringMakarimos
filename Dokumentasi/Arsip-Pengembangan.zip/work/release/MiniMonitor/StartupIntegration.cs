using System;
using System.Runtime.InteropServices;
using System.Security.Principal;

static class StartupIntegration
{
    public static string TaskName { get { using (var identity = WindowsIdentity.GetCurrent()) return "MiniMonitor-" + identity.User.Value; } }
    static void Release(object obj) { if (obj != null && Marshal.IsComObject(obj)) Marshal.FinalReleaseComObject(obj); }
    public static bool IsEnabled()
    {
        object service = null, folder = null, task = null;
        try
        {
            dynamic s = service = Activator.CreateInstance(Type.GetTypeFromProgID("Schedule.Service")); s.Connect();
            dynamic f = folder = s.GetFolder("\\"); dynamic t = task = f.GetTask(TaskName); return (bool)t.Enabled;
        }
        catch { return false; }
        finally { Release(task); Release(folder); Release(service); }
    }
    public static void Toggle()
    {
        object service = null, folder = null, task = null;
        try
        {
            dynamic s = service = Activator.CreateInstance(Type.GetTypeFromProgID("Schedule.Service")); s.Connect();
            dynamic f = folder = s.GetFolder("\\"); dynamic t = task = f.GetTask(TaskName); t.Enabled = !(bool)t.Enabled;
        }
        catch (COMException) { throw new InvalidOperationException("Jalankan Pasang-Otomatis.cmd sekali untuk memasang aplikasi dan startup Windows."); }
        finally { Release(task); Release(folder); Release(service); }
    }
}
