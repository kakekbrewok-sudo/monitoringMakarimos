$ErrorActionPreference = 'Stop'
$workspace = 'C:\Users\Makarim\Documents\Codex\2026-10-11\co'
$source = Join-Path $workspace 'work\release31\MiniMonitor'
$qa = Join-Path $workspace 'work\qa31'
$installed = 'C:\Program Files\MiniMonitor\MiniMonitor.exe'
try {
    $updateArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f (Join-Path $source 'Startup.ps1')),'-Mode','Update','-ResultPath',('"{0}"' -f (Join-Path $qa 'update-result.txt')))
    $update = Start-Process powershell.exe -ArgumentList $updateArgs -WindowStyle Hidden -PassThru
    if (-not $update.WaitForExit(40000)) { throw 'Update is still running.' }
    if ($update.ExitCode -ne 0) { throw ('Update exit code: '+$update.ExitCode) }
    $probeArgs = '--probe "{0}" "{1}"' -f (Join-Path $qa 'installed-live.txt'),$qa
    $probe = Start-Process -FilePath $installed -ArgumentList $probeArgs -WindowStyle Hidden -PassThru
    if (-not $probe.WaitForExit(30000)) { throw 'Sensor probe is still running.' }
    if ($probe.ExitCode -ne 0) { throw ('Probe exit code: '+$probe.ExitCode) }
    $report = Get-Content -LiteralPath (Join-Path $qa 'installed-live.txt') -Raw
    if ($report -notmatch '(?m)^CPU \|.*\| [0-9.]+ C \| Load [0-9.]+%') { throw 'CPU usage/temperature validation failed.' }
    if ($report -notmatch '(?m)^GPU \|.*\| [0-9.]+ C \| Load [0-9.]+%') { throw 'GPU usage/temperature validation failed.' }
    if ([regex]::Matches($report,'(?m)^SSD \|').Count -lt 2) { throw 'Both SSDs were not found.' }
    $sourceHash = (Get-FileHash (Join-Path $source 'MiniMonitor.exe') -Algorithm SHA256).Hash
    $targetHash = (Get-FileHash $installed -Algorithm SHA256).Hash
    if ($sourceHash -ne $targetHash) { throw 'Installed EXE does not match the build.' }
    $task = Get-ScheduledTask -TaskName ('MiniMonitor-'+[Security.Principal.WindowsIdentity]::GetCurrent().User.Value)
    $main = Get-Process -Name MiniMonitor | Where-Object {$_.MainModule.FileName -eq $installed} | Select-Object -First 1
    if (-not $main) { throw 'Updated application is not running.' }
    @('PASS: installed build hash matches', 'PASS: live CPU and GPU usage + temperature', 'PASS: both SSD sensors', ('PASS: application running, PID '+$main.Id), ('Startup enabled: '+$task.Settings.Enabled), ('RAM MB: '+[Math]::Round($main.WorkingSet64/1MB,1))) | Set-Content (Join-Path $qa 'installed-checks.txt')
} catch {
    ('ERROR: '+$_.Exception.Message) | Set-Content (Join-Path $qa 'installed-checks.txt')
    exit 1
}
