$ErrorActionPreference = 'Stop'
$workspace = 'C:\Users\Makarim\Documents\Codex\2026-10-11\co'
$qa = Join-Path $workspace 'work\qa321'
$installed = 'C:\Program Files\MiniMonitor\MiniMonitor.exe'
$source = Join-Path $workspace 'work\release321\MiniMonitor'
$statusPath = Join-Path $qa 'fix-status.txt'
try {
    'Stopping the installed instance to isolate foreground-focus tests.' | Set-Content $statusPath
    foreach ($p in @(Get-Process -Name MiniMonitor -ErrorAction SilentlyContinue)) {
        if ($p.MainModule.FileName -eq $installed) {
            $null = $p.CloseMainWindow()
            if (-not $p.WaitForExit(8000)) { Stop-Process -Id $p.Id; $null = $p.WaitForExit(5000) }
        }
    }
    'Testing the previous build with real tray, clock and sensor timers.' | Add-Content $statusPath
    $beforeArgs = '"{0}" before-fix.txt' -f $qa
    $before = Start-Process (Join-Path $qa 'BeforeFix.exe') -ArgumentList $beforeArgs -PassThru
    if (-not $before.WaitForExit(70000)) { Stop-Process -Id $before.Id; throw 'Baseline test timed out.' }
    $beforeResult = Get-Content (Join-Path $qa 'before-fix.txt') -Raw
    if ($beforeResult -notmatch 'FAIL: Pinned window / root: menu survives multiple live refreshes') {
        throw ('Expected baseline failure was not reproduced: '+$beforeResult)
    }
    'Reproduced: previous build dismisses the tray menu during live refresh.' | Add-Content $statusPath
    'Testing fixed build: pinned window, overlay, hidden tray and normal menu mode.' | Add-Content $statusPath
    $afterArgs = '"{0}" after-fix.txt' -f $qa
    $after = Start-Process (Join-Path $qa 'AfterFix.exe') -ArgumentList $afterArgs -PassThru
    if (-not $after.WaitForExit(70000)) { Stop-Process -Id $after.Id; throw 'Fixed-build test timed out.' }
    if ($after.ExitCode -ne 0) { throw ('Fixed-build test failed: '+(Get-Content (Join-Path $qa 'after-fix.txt') -Raw)) }
    'Live tray regression tests passed. Installing the fix.' | Add-Content $statusPath
    $updateArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f (Join-Path $source 'Startup.ps1')),'-Mode','Update','-ResultPath',('"{0}"' -f (Join-Path $qa 'update-result.txt')))
    $update = Start-Process powershell.exe -ArgumentList $updateArgs -WindowStyle Hidden -PassThru
    if (-not $update.WaitForExit(40000)) { throw 'Update timed out.' }
    if ($update.ExitCode -ne 0) { throw ('Update failed: '+$update.ExitCode) }
    $sourceHash = (Get-FileHash (Join-Path $source 'MiniMonitor.exe') -Algorithm SHA256).Hash
    if ($sourceHash -ne (Get-FileHash $installed -Algorithm SHA256).Hash) { throw 'Installed EXE does not match the fixed build.' }
    $task = Get-ScheduledTask -TaskName ('MiniMonitor-'+[Security.Principal.WindowsIdentity]::GetCurrent().User.Value)
    $main = Get-Process -Name MiniMonitor | Where-Object {$_.MainModule.FileName -eq $installed} | Select-Object -First 1
    if (-not $main) { throw 'Updated application is not running.' }
    @('PASS: installed build matches the tested fix', ('PASS: updated application running, PID '+$main.Id), ('Startup enabled: '+$task.Settings.Enabled)) | Set-Content (Join-Path $qa 'installed-checks.txt')
    'COMPLETE: fixed build installed and running.' | Add-Content $statusPath
} catch {
    ('ERROR: '+$_.Exception.Message) | Add-Content $statusPath
    $main = Get-Process -Name MiniMonitor -ErrorAction SilentlyContinue | Where-Object {$_.MainModule.FileName -eq $installed}
    if (-not $main -and (Test-Path -LiteralPath $installed)) { Start-Process $installed -ArgumentList '--startup' }
    exit 1
}
