$a=[Reflection.Assembly]::LoadFrom('C:\Users\Makarim\Documents\Codex\2026-10-11\co\outputs\MiniMonitor\sensors\DiskInfoToolkit.dll')
$a.GetType('DiskInfoToolkit.Storage').GetProperties() | Select-Object Name | Format-Table
