$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$workspace='C:\Users\Makarim\Documents\Codex\2026-10-11\co'
$keys=@('dot-black','dot-white','kanji-art','g-shock')
$labels=@('01  DOT HITAM','02  DOT PUTIH','03  KANJI ART','04  G-SHOCK')
$board=New-Object Drawing.Bitmap (1376,536)
$g=[Drawing.Graphics]::FromImage($board)
$g.Clear([Drawing.Color]::FromArgb(223,224,218))
$g.TextRenderingHint=[Drawing.Text.TextRenderingHint]::AntiAliasGridFit
$title=New-Object Drawing.Font ('Segoe UI',18,[Drawing.FontStyle]::Bold)
$label=New-Object Drawing.Font ('Segoe UI',10,[Drawing.FontStyle]::Bold)
$small=New-Object Drawing.Font ('Segoe UI',10)
$ink=New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(36,39,35))
$g.DrawString('MINI MONITOR / 4 TEMA',$title,$ink,28,14)
$g.DrawString('Pratinjau dari aplikasi asli. Data aplikasi dan sensor pada contoh ini disimulasikan.',$small,$ink,30,49)
for($i=0; $i -lt 4; $i++) {
    $x=28+336*$i
    $g.DrawString($labels[$i],$label,$ink,$x,83)
    $image=[Drawing.Image]::FromFile((Join-Path $workspace ('work\qa33\'+$keys[$i]+'.png')))
    $g.DrawImageUnscaled($image,$x,108)
    $image.Dispose()
}
$board.Save((Join-Path $workspace 'outputs\MiniMonitor-Tema.png'),[Drawing.Imaging.ImageFormat]::Png)
$ink.Dispose(); $small.Dispose(); $label.Dispose(); $title.Dispose(); $g.Dispose(); $board.Dispose()
