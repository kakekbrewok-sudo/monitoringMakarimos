// Mini Monitor 2: native Windows Forms / .NET Framework 4.7.2+.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibreHardwareMonitor.Hardware;
using Microsoft.Win32;

static class Native
{
    [StructLayout(LayoutKind.Sequential)] public struct Memory
    {
        public uint Length, Load;
        public ulong Total, Available, Page, AvailablePage, Virtual, AvailableVirtual, Extended;
    }
    [DllImport("kernel32.dll")] public static extern bool GlobalMemoryStatusEx(ref Memory m);
    [DllImport("user32.dll")] public static extern bool ReleaseCapture();
    [DllImport("user32.dll")] public static extern IntPtr SendMessage(IntPtr h, int m, IntPtr w, IntPtr l);
    [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr h, int id, uint mods, uint key);
    [DllImport("user32.dll")] public static extern bool UnregisterHotKey(IntPtr h, int id);
    [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int index);
    [DllImport("user32.dll")] public static extern int SetWindowLong(IntPtr h, int index, int value);
    public static bool Admin { get { using (var i = WindowsIdentity.GetCurrent()) return new WindowsPrincipal(i).IsInRole(WindowsBuiltInRole.Administrator); } }
    public static bool DriverInstalled
    {
        get
        {
            using (var root = RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64))
            using (var key = root.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\PawnIO")) return key != null;
        }
    }
}

sealed class Reading
{
    public string Kind, Name, Sensor, Error;
    public float? Value;
    public Reading(string kind, string name) { Kind = kind; Name = name; }
    public string Text { get { return Value.HasValue ? Value.Value.ToString("0") + " °C" : "—"; } }
}

sealed class Snapshot
{
    public double Used, Total;
    public uint Load;
    public bool MemoryValid;
    public DateTime Timestamp = DateTime.Now;
    public Reading Cpu = new Reading("CPU", "Membaca sensor CPU...");
    public Reading Gpu = new Reading("GPU", "Membaca sensor GPU...");
    public List<Reading> Disks = new List<Reading>();
    public string Error;
}

sealed class SensorReader : IDisposable
{
    Computer computer;
    DateTime nextDiskRead = DateTime.MinValue;
    List<Reading> disks = new List<Reading>();
    string openError;
    public SensorReader()
    {
        computer = new Computer { IsCpuEnabled = true, IsGpuEnabled = true, IsStorageEnabled = true };
        LibreHardwareMonitor.Hardware.Storage.StorageDevice.ThrottleInterval = TimeSpan.FromSeconds(15);
        try { computer.Open(); } catch (Exception ex) { openError = ex.GetBaseException().Message; }
    }
    public static bool Valid(float? v) { return v.HasValue && !float.IsNaN(v.Value) && v.Value > 0 && v.Value < 150; }
    public static int Rank(string kind, string name)
    {
        string n = name.ToLowerInvariant();
        // NVMe also exposes warning/critical thresholds as Temperature sensors.
        if (n.Contains("critical") || n.Contains("warning") || n.Contains("limit") || n.Contains("distance") || n.Contains("t.j.") || n.Contains("tj max")) return -1;
        if (kind == "CPU") return n.Contains("tctl/tdie") || n.Contains("package") ? 100 : n.Contains("tdie") ? 90 : 10;
        if (kind == "GPU") return n == "gpu core" ? 100 : n.Contains("hot spot") || n.Contains("memory") ? 5 : 20;
        return n.Contains("composite") ? 100 : n == "temperature" ? 90 : 10;
    }
    static void Update(IHardware h) { h.Update(); foreach (IHardware child in h.SubHardware) Update(child); }
    static IEnumerable<ISensor> Sensors(IHardware h)
    {
        foreach (ISensor s in h.Sensors) yield return s;
        foreach (IHardware child in h.SubHardware) foreach (ISensor s in Sensors(child)) yield return s;
    }
    static Reading Read(IHardware h, string kind)
    {
        var r = new Reading(kind, h.Name);
        try
        {
            Update(h);
            ISensor selected = Sensors(h).Where(s => s.SensorType == SensorType.Temperature && Valid(s.Value) && Rank(kind, s.Name) >= 0)
                .OrderByDescending(s => Rank(kind, s.Name)).ThenByDescending(s => s.Value.Value).FirstOrDefault();
            if (selected != null) { r.Value = selected.Value; r.Sensor = selected.Name; }
        }
        catch (Exception ex) { r.Error = ex.GetBaseException().Message; }
        return r;
    }
    static string DiskKind(IHardware h)
    {
        try
        {
            object storage = h.GetType().GetProperty("Storage").GetValue(h, null);
            foreach (string property in new[] { "IsSSD", "IsNVMe" })
            { var p = storage.GetType().GetProperty(property); if (p != null && (bool)p.GetValue(storage, null)) return "SSD"; }
        }
        catch { }
        return "HDD";
    }
    public Snapshot Poll()
    {
        var r = new Snapshot { Error = openError };
        var m = new Native.Memory { Length = (uint)Marshal.SizeOf(typeof(Native.Memory)) };
        if (Native.GlobalMemoryStatusEx(ref m)) { r.MemoryValid = true; r.Load = m.Load; r.Total = m.Total / 1073741824.0; r.Used = (m.Total - m.Available) / 1073741824.0; }
        bool diskDue = DateTime.UtcNow >= nextDiskRead, cpuSeen = false, gpuSeen = false;
        var freshDisks = new List<Reading>();
        foreach (IHardware h in computer.Hardware)
        {
            string type = h.HardwareType.ToString();
            if (type == "Cpu")
            {
                Reading item = Read(h, "CPU");
                if (!cpuSeen || (item.Value.HasValue && (!r.Cpu.Value.HasValue || item.Value > r.Cpu.Value))) r.Cpu = item;
                cpuSeen = true;
            }
            else if (type.StartsWith("Gpu", StringComparison.Ordinal))
            {
                Reading item = Read(h, "GPU");
                if (!gpuSeen || (item.Value.HasValue && (!r.Gpu.Value.HasValue || item.Value > r.Gpu.Value))) r.Gpu = item;
                gpuSeen = true;
            }
            else if (type == "Storage" && diskDue) freshDisks.Add(Read(h, DiskKind(h)));
        }
        if (diskDue) { disks = freshDisks.OrderBy(d => d.Kind == "SSD" ? 0 : 1).ThenBy(d => d.Name).ToList(); nextDiskRead = DateTime.UtcNow.AddSeconds(15); }
        r.Disks = disks;
        if (!cpuSeen) r.Cpu.Name = "CPU tidak terdeteksi";
        if (!gpuSeen) r.Gpu.Name = "GPU tidak terdeteksi";
        return r;
    }
    public string Report(Snapshot s)
    {
        var b = new StringBuilder(); b.AppendLine("Mini Monitor 2 | " + s.Timestamp.ToString("s"));
        b.AppendLine("Administrator: " + Native.Admin + " | PawnIO installed: " + Native.DriverInstalled);
        b.AppendLine(String.Format(CultureInfo.InvariantCulture, "RAM: {0:0.00}/{1:0.00} GB ({2}%)", s.Used, s.Total, s.Load));
        foreach (Reading r in new[] { s.Cpu, s.Gpu }.Concat(s.Disks)) b.AppendLine(r.Kind + " | " + r.Name + " | " + r.Sensor + " | " + (r.Value.HasValue ? r.Value.Value.ToString("0.0", CultureInfo.InvariantCulture) + " C" : "unavailable") + " | " + r.Error);
        if (s.Error != null) b.AppendLine("Error: " + s.Error);
        return b.ToString();
    }
    public void Dispose() { if (computer != null) { try { computer.Close(); } catch { } computer = null; } }
}

sealed class MonitorWindow : Form
{
    readonly System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
    readonly ContextMenuStrip menu = new ContextMenuStrip();
    readonly NotifyIcon tray = new NotifyIcon();
    readonly ToolTip tip = new ToolTip();
    readonly Font heading = new Font("Segoe UI", 9f, FontStyle.Bold), small = new Font("Segoe UI", 8.5f), value = new Font("Segoe UI", 17f, FontStyle.Bold), compact = new Font("Segoe UI", 11f, FontStyle.Bold);
    readonly Color accent = Color.FromArgb(115, 222, 202), muted = Color.FromArgb(153, 167, 183);
    readonly string settingsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "MiniMonitor.settings");
    SensorReader reader;
    Snapshot data = new Snapshot();
    ToolStripMenuItem overlayItem, lockItem, topItem;
    bool overlay = true, locked, busy, closing, mayClose, installing, lockHotkey, pin = true;
    int interval = 3000;
    float scale = 1;
    double overlayOpacity = .94;
    DateTime lastPoll = DateTime.MinValue;
    string transient;
    public MonitorWindow(bool? overlayOverride)
    {
        Text = "Mini Monitor 2"; BackColor = Color.FromArgb(19, 25, 33); ForeColor = Color.FromArgb(234, 242, 250);
        DoubleBuffered = true; MaximizeBox = false; AutoScaleMode = AutoScaleMode.None;
        using (Graphics g = CreateGraphics()) scale = g.DpiX / 96f;
        ReadSettings(); if (overlayOverride.HasValue) overlay = overlayOverride.Value;
        BuildMenu(); ContextMenuStrip = menu;
        tray.Icon = SystemIcons.Application; tray.Text = "Mini Monitor 2"; tray.ContextMenuStrip = menu; tray.Visible = true;
        tray.DoubleClick += (s, e) => RestoreWindow();
        timer.Interval = interval; timer.Tick += async (s, e) => await PollAsync();
        MouseDown += (s, e) => { if (e.Button == MouseButtons.Left && !locked) { Native.ReleaseCapture(); Native.SendMessage(Handle, 0xA1, new IntPtr(2), IntPtr.Zero); } };
        MouseDoubleClick += (s, e) => { if (e.Button == MouseButtons.Left && !locked) SetOverlay(!overlay); };
        Resize += (s, e) => { if (WindowState == FormWindowState.Minimized) Hide(); };
        Shown += async (s, e) => { await PollAsync(); if (!closing) timer.Start(); };
        FormClosing += HandleClosing; ApplyLayout();
        var area = Screen.FromPoint(Location).WorkingArea;
        if (!area.Contains(Bounds)) Location = new Point(Math.Max(area.Left, Math.Min(Left, area.Right - Width)), Math.Max(area.Top, Math.Min(Top, area.Bottom - Height)));
    }
    int S(int n) { return (int)Math.Round(n * scale); }
    void BuildMenu()
    {
        menu.Items.Add("Tampilkan / buka kunci", null, (s, e) => RestoreWindow());
        overlayItem = new ToolStripMenuItem("Mode overlay (Ctrl+Alt+O)", null, (s, e) => SetOverlay(!overlay)); menu.Items.Add(overlayItem);
        lockItem = new ToolStripMenuItem("Klik tembus (Ctrl+Alt+L)", null, (s, e) => SetLocked(!locked)); menu.Items.Add(lockItem);
        topItem = new ToolStripMenuItem("Selalu di atas", null, (s, e) => { pin = !pin; TopMost = overlay || pin; SaveSettings(); }); menu.Items.Add(topItem);
        var speed = new ToolStripMenuItem("Pembaruan");
        foreach (int seconds in new[] { 1, 3, 5 })
        {
            int ms = seconds * 1000; var item = new ToolStripMenuItem(seconds + " detik" + (seconds == 3 ? " (default)" : ""));
            item.Click += (s, e) => { interval = ms; timer.Interval = interval; SetTooltip(); SaveSettings(); Invalidate(); }; item.Tag = ms; speed.DropDownItems.Add(item);
        }
        menu.Items.Add(speed);
        var transparency = new ToolStripMenuItem("Opasitas overlay");
        foreach (int percent in new[] { 75, 90, 100 }) { double opacity = percent / 100.0; transparency.DropDownItems.Add(percent + "%", null, (s, e) => { overlayOpacity = opacity; if (overlay) Opacity = opacity; SaveSettings(); }); }
        menu.Items.Add(transparency); menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Perbaiki / pasang driver CPU...", null, async (s, e) => await InstallDriver());
        menu.Items.Add("Mulai ulang sebagai administrator", null, (s, e) => Restart());
        menu.Items.Add("Simpan diagnostik...", null, (s, e) => SaveReport()); menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Keluar", null, (s, e) => Close());
        menu.Opening += (s, e) => { overlayItem.Checked = overlay; lockItem.Checked = locked; lockItem.Enabled = overlay && lockHotkey; topItem.Checked = TopMost; topItem.Enabled = !overlay; foreach (ToolStripMenuItem item in speed.DropDownItems) item.Checked = (int)item.Tag == interval; };
    }
    protected override void OnHandleCreated(EventArgs e) { base.OnHandleCreated(e); lockHotkey = Native.RegisterHotKey(Handle, 1, 0x4003, (uint)Keys.L); Native.RegisterHotKey(Handle, 2, 0x4003, (uint)Keys.O); }
    protected override void OnHandleDestroyed(EventArgs e) { Native.UnregisterHotKey(Handle, 1); Native.UnregisterHotKey(Handle, 2); base.OnHandleDestroyed(e); }
    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x312) { if (m.WParam.ToInt32() == 1) { if (locked) RestoreWindow(); else if (overlay) SetLocked(true); } else if (m.WParam.ToInt32() == 2) { Show(); SetOverlay(!overlay); } }
        base.WndProc(ref m);
    }
    void SetLocked(bool enabled)
    {
        locked = enabled && overlay && lockHotkey; int style = Native.GetWindowLong(Handle, -20);
        Native.SetWindowLong(Handle, -20, locked ? style | 0x80000 | 0x20 | 0x08000000 : style & ~0x20 & ~0x08000000); Invalidate();
    }
    void RestoreWindow() { SetLocked(false); Show(); WindowState = FormWindowState.Normal; Activate(); }
    void SetOverlay(bool enabled) { SetLocked(false); overlay = enabled; ApplyLayout(); SaveSettings(); Invalidate(); }
    void ApplyLayout()
    {
        Point old = Location; var wanted = overlay ? FormBorderStyle.None : FormBorderStyle.FixedSingle;
        if (FormBorderStyle != wanted) FormBorderStyle = wanted;
        ShowInTaskbar = !overlay; TopMost = overlay || pin; Opacity = overlay ? overlayOpacity : 1;
        int rows = 3 + Math.Max(1, data.Disks.Count);
        Size size = new Size(S(overlay ? 300 : 440), S(overlay ? 66 + rows * 30 : 98 + rows * 62));
        if (ClientSize != size) ClientSize = size;
        Location = old; if (locked) SetLocked(true);
    }
    async Task PollAsync()
    {
        if (busy || closing || installing) return; busy = true;
        try
        {
            Snapshot fresh = await Task.Run(() => { if (reader == null) reader = new SensorReader(); return reader.Poll(); });
            if (!closing) { transient = null; data = fresh; lastPoll = DateTime.Now; ApplyLayout(); SetTooltip(); Invalidate(); }
        }
        catch (Exception ex) { transient = "Sensor: " + ex.GetBaseException().Message; data = new Snapshot { Error = transient }; if (!closing) Invalidate(); }
        finally { busy = false; }
        if (closing) await FinishClose();
    }
    string StatusText()
    {
        if (closing) return "Menutup sensor..."; if (installing) return "Memasang driver CPU..."; if (transient != null) return transient;
        if (lastPoll == DateTime.MinValue) return "Membaca perangkat...";
        if (!data.Cpu.Value.HasValue) { if (!Native.DriverInstalled) return "CPU: klik kanan > pasang driver"; if (!Native.Admin) return "CPU: jalankan sebagai administrator"; return "CPU belum terbaca · lihat diagnostik"; }
        if (data.Disks.Count == 0 || data.Disks.All(d => !d.Value.HasValue)) return "SSD belum terbaca · lihat diagnostik";
        return locked ? "Terkunci · Ctrl+Alt+L untuk membuka" : overlay ? "Geser · klik kanan untuk opsi" : "Klik kanan: overlay, interval, dan opsi";
    }
    void SetTooltip()
    {
        var b = new StringBuilder(); foreach (Reading r in new[] { data.Cpu, data.Gpu }.Concat(data.Disks)) b.AppendLine(r.Kind + ": " + r.Name + "\n" + (r.Sensor ?? "Sensor tidak tersedia") + " · " + r.Text);
        b.Append("RAM = pemakaian memori fisik\nCPU/GPU/RAM: " + interval / 1000 + " detik | SSD/disk: 15 detik"); tip.SetToolTip(this, b.ToString());
        tray.Text = "CPU " + data.Cpu.Text + " | GPU " + data.Gpu.Text + " | RAM " + data.Load + "%";
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e); Graphics g = e.Graphics; using (var pen = new Pen(Color.FromArgb(49, 64, 79))) g.DrawRectangle(pen, 0, 0, ClientSize.Width - 1, ClientSize.Height - 1);
        int width = (int)(ClientSize.Width / scale); DrawText(g, "MINI MONITOR", heading, accent, new Rectangle(14, 11, 160, 22));
        DrawText(g, interval / 1000 + "s / disk 15s", small, muted, new Rectangle(width - 117, 11, 104, 22), true);
        int y = overlay ? 36 : 50;
        DrawRow(g, "RAM", data.MemoryValid ? data.Load + "%" : "—", String.Format("{0:0.0} / {1:0.0} GB", data.Used, data.Total), y, null, data.MemoryValid ? data.Load / 100f : 0); y += overlay ? 30 : 62;
        DrawRow(g, "CPU", data.Cpu.Text, data.Cpu.Name, y, data.Cpu.Value, null); y += overlay ? 30 : 62;
        DrawRow(g, "GPU", data.Gpu.Text, data.Gpu.Name, y, data.Gpu.Value, null); y += overlay ? 30 : 62;
        if (data.Disks.Count == 0) DrawRow(g, "SSD", "—", "Menunggu sensor penyimpanan", y, null, null);
        int ssdIndex = 1, hddIndex = 1;
        foreach (Reading d in data.Disks) { DrawRow(g, d.Kind + " " + (d.Kind == "SSD" ? ssdIndex++ : hddIndex++), d.Text, d.Name, y, d.Value, null); y += overlay ? 30 : 62; }
        DrawText(g, StatusText(), small, muted, new Rectangle(14, (int)(ClientSize.Height / scale) - 24, width - 28, 20));
    }
    void DrawText(Graphics g, string text, Font font, Color color, Rectangle r, bool right = false)
    {
        var rect = new Rectangle(S(r.X), S(r.Y), S(r.Width), S(r.Height));
        TextRenderer.DrawText(g, text ?? "", font, rect, color, TextFormatFlags.NoPrefix | TextFormatFlags.SingleLine | TextFormatFlags.EndEllipsis | TextFormatFlags.VerticalCenter | (right ? TextFormatFlags.Right : TextFormatFlags.Left));
    }
    void DrawRow(Graphics g, string name, string reading, string detail, int y, float? temp, float? fraction)
    {
        int width = (int)(ClientSize.Width / scale); Color color = temp.HasValue && temp >= 85 ? Color.FromArgb(255, 168, 113) : ForeColor;
        if (overlay) { DrawText(g, name, heading, muted, new Rectangle(14, y, 57, 26)); DrawText(g, detail, small, muted, new Rectangle(73, y, width - 165, 26)); DrawText(g, reading, compact, color, new Rectangle(width - 85, y, 71, 26), true); }
        else
        {
            DrawText(g, name, heading, accent, new Rectangle(18, y, 70, 23)); DrawText(g, detail, small, muted, new Rectangle(18, y + 22, width - 134, 24)); DrawText(g, reading, value, color, new Rectangle(width - 124, y, 106, 44), true);
            if (fraction.HasValue) { using (var b = new SolidBrush(Color.FromArgb(39, 52, 65))) g.FillRectangle(b, S(18), S(y + 50), S(width - 36), S(2)); using (var b = new SolidBrush(accent)) g.FillRectangle(b, S(18), S(y + 50), S((int)((width - 36) * fraction.Value)), S(2)); }
        }
    }
    async Task InstallDriver()
    {
        if (installing || busy) { transient = "Tunggu pembacaan selesai, lalu coba lagi"; Invalidate(); return; }
        string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "setup", "PawnIO_setup.exe");
        if (!File.Exists(path)) { MessageBox.Show(this, "Ekstrak seluruh ZIP agar installer driver tersedia.", Text); return; }
        installing = true; timer.Stop(); transient = null; Invalidate();
        try
        {
            using (var p = Process.Start(new ProcessStartInfo(path, "-install") { UseShellExecute = true, Verb = "runas" })) { await Task.Run(() => p.WaitForExit()); if (p.ExitCode != 0) throw new Exception("Installer berhenti dengan kode " + p.ExitCode); }
            if (!Native.DriverInstalled) throw new Exception("PawnIO belum terpasang"); if (!closing) Restart();
        }
        catch (Exception ex) { transient = "Pemasangan belum selesai"; if (!closing) MessageBox.Show(this, ex.GetBaseException().Message, Text); }
        finally { installing = false; if (!closing) { timer.Start(); Invalidate(); } }
    }
    void Restart()
    {
        try { SaveSettings(); Process.Start(new ProcessStartInfo(Application.ExecutablePath, "--elevated") { UseShellExecute = true, Verb = "runas" }); Close(); }
        catch (Exception ex) { transient = "Akses administrator belum diberikan"; MessageBox.Show(this, ex.Message, Text); }
    }
    void SaveReport()
    {
        using (var dialog = new SaveFileDialog { Filter = "Text file|*.txt", FileName = "MiniMonitor-diagnostik.txt" })
            if (dialog.ShowDialog(this) == DialogResult.OK) try { File.WriteAllText(dialog.FileName, reader != null ? reader.Report(data) : "Sensor belum selesai dibuka."); } catch (Exception ex) { MessageBox.Show(this, ex.Message, Text); }
    }
    void ReadSettings()
    {
        StartPosition = FormStartPosition.Manual; var area = Screen.PrimaryScreen.WorkingArea; Location = new Point(area.Right - S(320), area.Top + S(30));
        try
        {
            if (!File.Exists(settingsPath)) return;
            foreach (string line in File.ReadAllLines(settingsPath))
            {
                string[] p = line.Split('='); if (p.Length != 2) continue; int n; double d;
                if (p[0] == "overlay") overlay = p[1] == "1"; if (p[0] == "pin") pin = p[1] == "1";
                if (p[0] == "interval" && int.TryParse(p[1], out n) && (n == 1000 || n == 3000 || n == 5000)) interval = n;
                if (p[0] == "x" && int.TryParse(p[1], out n)) Left = n; if (p[0] == "y" && int.TryParse(p[1], out n)) Top = n;
                if (p[0] == "opacity" && double.TryParse(p[1], NumberStyles.Any, CultureInfo.InvariantCulture, out d) && d >= .5 && d <= 1) overlayOpacity = d;
            }
        }
        catch { }
    }
    void SaveSettings() { try { File.WriteAllLines(settingsPath, new[] { "overlay=" + (overlay ? "1" : "0"), "pin=" + (pin ? "1" : "0"), "interval=" + interval, "x=" + Left, "y=" + Top, "opacity=" + overlayOpacity.ToString(CultureInfo.InvariantCulture) }); } catch { } }
    async void HandleClosing(object sender, FormClosingEventArgs e)
    {
        if (mayClose) return; e.Cancel = true; if (closing) return; closing = true; timer.Stop(); SaveSettings(); Invalidate(); if (!busy) await FinishClose();
    }
    async Task FinishClose() { if (mayClose) return; if (reader != null) { SensorReader old = reader; reader = null; await Task.Run(() => old.Dispose()); } mayClose = true; Close(); }
    protected override void Dispose(bool disposing) { if (disposing) { timer.Dispose(); tray.Visible = false; tray.Dispose(); menu.Dispose(); tip.Dispose(); heading.Dispose(); small.Dispose(); value.Dispose(); compact.Dispose(); } base.Dispose(disposing); }
    internal void Render(Snapshot sample, bool compactMode, string path)
    {
        data = sample; lastPoll = DateTime.Now; overlay = compactMode; ApplyLayout();
        using (var bitmap = new Bitmap(Width, Height)) { DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size)); bitmap.Save(path); }
    }
}

static class Program
{
    [STAThread] static int Main(string[] args)
    {
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        try
        {
            if (args.Length >= 2 && args[0] == "--probe")
            {
                using (var reader = new SensorReader())
                {
                    Snapshot sample = reader.Poll(); System.Threading.Thread.Sleep(1500); sample = reader.Poll(); File.WriteAllText(args[1], reader.Report(sample));
                    if (args.Length >= 3) using (var form = new MonitorWindow(null)) { form.Render(sample, true, Path.Combine(args[2], "overlay-preview.png")); form.Render(sample, false, Path.Combine(args[2], "window-preview.png")); }
                }
                return 0;
            }
            if (!Native.Admin && !args.Contains("--no-elevate") && !args.Contains("--elevated"))
            {
                try { Process.Start(new ProcessStartInfo(Application.ExecutablePath, "--elevated " + String.Join(" ", args)) { UseShellExecute = true, Verb = "runas" }); return 0; }
                catch (System.ComponentModel.Win32Exception) { }
            }
            bool? mode = args.Contains("--window") ? (bool?)false : args.Contains("--overlay") ? (bool?)true : null;
            Application.Run(new MonitorWindow(mode)); return 0;
        }
        catch (Exception ex)
        {
            if (args.Length >= 2 && args[0] == "--probe") File.WriteAllText(args[1], "ERROR: " + ex); else MessageBox.Show(ex.GetBaseException().Message, "Mini Monitor"); return 1;
        }
    }
}
