$ErrorActionPreference = 'Stop'
$workspace = 'C:\Users\Makarim\Documents\Codex\2026-10-11\co'
$qa = Join-Path $workspace 'work\qa33'
$installed = 'C:\Program Files\MiniMonitor\MiniMonitor.exe'
$source = Join-Path $workspace 'work\release33\MiniMonitor'
$statusPath = Join-Path $qa 'update-status.txt'
try {
    $testReport = Get-Content (Join-Path $qa 'isolated-live.txt') -Raw
    if ($testReport -match 'FAIL:|Exception' -or $testReport -notmatch 'PASS: GShock: correct theme without moving or recreating window' -or $testReport -notmatch 'PASS: normal menu mode closes only after selecting an option') { throw 'Final native menu tests have not passed.' }
    'All four final themes and live tray regression tests passed on an isolated native desktop. Installing.' | Set-Content $statusPath
    $updateArgs = @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"{0}"' -f (Join-Path $source 'Startup.ps1')),'-Mode','Update','-ResultPath',('"{0}"' -f (Join-Path $qa 'update-result.txt')))
    $update = Start-Process powershell.exe -ArgumentList $updateArgs -WindowStyle Hidden -PassThru
    if (-not $update.WaitForExit(40000)) { throw 'Update timed out.' }
    if ($update.ExitCode -ne 0) { throw ('Update failed: '+$update.ExitCode) }
    $probeArgs = '--probe "{0}" "{1}"' -f (Join-Path $qa 'installed-live.txt'),$qa
    $probe = Start-Process -FilePath $installed -ArgumentList $probeArgs -WindowStyle Hidden -PassThru
    if (-not $probe.WaitForExit(30000)) { throw 'Sensor probe timed out.' }
    if ($probe.ExitCode -ne 0) { throw ('Sensor probe failed: '+$probe.ExitCode) }
    $sourceHash = (Get-FileHash (Join-Path $source 'MiniMonitor.exe') -Algorithm SHA256).Hash
    if ($sourceHash -ne (Get-FileHash $installed -Algorithm SHA256).Hash) { throw 'Installed EXE does not match the tested build.' }
    $report = Get-Content (Join-Path $qa 'installed-live.txt') -Raw
    if ($report -notmatch '(?m)^CPU \|.*\| [0-9.]+ C \| Load [0-9.]+%') { throw 'CPU usage/temperature unavailable.' }
    if ($report -notmatch '(?m)^GPU \|.*\| [0-9.]+ C \| Load [0-9.]+%') { throw 'GPU usage/temperature unavailable.' }
    if ([regex]::Matches($report,'(?m)^SSD \|').Count -lt 2) { throw 'Expected two SSD sensors.' }
    $task = Get-ScheduledTask -TaskName ('MiniMonitor-'+[Security.Principal.WindowsIdentity]::GetCurrent().User.Value)
    $main = Get-Process -Name MiniMonitor | Where-Object {$_.MainModule.FileName -eq $installed} | Select-Object -First 1
    if (-not $main) { throw 'Updated application is not running.' }
    @('PASS: installed build matches tested version 3.3', 'PASS: CPU/GPU usage and temperatures; both SSD sensors', ('PASS: application running, PID '+$main.Id), ('Startup enabled: '+$task.Settings.Enabled), ('RAM MB (snapshot): '+[Math]::Round($main.WorkingSet64/1MB,1))) | Set-Content (Join-Path $qa 'installed-checks.txt')
    'COMPLETE: four themes installed and running.' | Add-Content $statusPath
} catch {
    ('ERROR: '+$_.Exception.Message) | Add-Content $statusPath
    $main = Get-Process -Name MiniMonitor -ErrorAction SilentlyContinue | Where-Object {$_.MainModule.FileName -eq $installed}
    if (-not $main -and (Test-Path -LiteralPath $installed)) { Start-Process $installed -ArgumentList '--startup' -WindowStyle Hidden }
    exit 1
}
