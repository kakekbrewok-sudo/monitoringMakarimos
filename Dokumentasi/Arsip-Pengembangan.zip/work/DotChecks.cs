using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

static class DotChecks
{
    static readonly StringBuilder log = new StringBuilder();
    static object Field(object o, string name) { return o.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(o); }
    static object Call(object o, string name) { return o.GetType().GetMethod(name, BindingFlags.Instance | BindingFlags.NonPublic).Invoke(o, null); }
    static void Check(bool ok, string label) { if (!ok) throw new Exception("FAIL: " + label); log.AppendLine("PASS: " + label); }
    [STAThread] static int Main(string[] args)
    {
        try
        {
            Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
            Check(!typeof(MonitorWindow).GetFields(BindingFlags.Instance | BindingFlags.NonPublic).Any(f => f.FieldType == typeof(ToolTip)), "overlay has no tooltip component");
            Check(StartupIntegration.IsEnabled(), "installed Windows logon task is enabled");
            using (var form = new MonitorWindow(true))
            {
                IntPtr handle = form.Handle;
                var task = (Task)Call(form, "PollAsync"); var timeout = Stopwatch.StartNew();
                while (!task.IsCompleted && timeout.ElapsedMilliseconds < 30000) { Application.DoEvents(); Thread.Sleep(10); }
                Check(task.IsCompleted, "sensor poll completes"); task.GetAwaiter().GetResult();
                Snapshot sample = (Snapshot)Field(form, "data");
                if (Native.Admin) Check(sample.Cpu.Value.HasValue && sample.Gpu.Value.HasValue && sample.Disks.Count(d => d.Kind == "SSD" && d.Value.HasValue) >= 2, "CPU, GPU and both SSDs still readable");
                else Check(sample.MemoryValid, "RAM remains available without administrator; temperature support was checked separately in the elevated probe");
                Check(((NotifyIcon)Field(form, "tray")).Text == "", "tray hover text removed");
                var activity = (ActivityTracker)Field(form, "activity");
                var clock = (System.Windows.Forms.Timer)Field(form, "clockTimer");
                using (var done = new System.Windows.Forms.Timer { Interval = 6500 })
                using (var context = new ApplicationContext())
                {
                    clock.Start(); done.Tick += (s, e) => { done.Stop(); clock.Stop(); context.ExitThread(); }; done.Start(); Application.Run(context);
                }
                if (activity.Selected != null) log.AppendLine("Foreground sample: " + activity.Selected.App.Name + " | active=" + ActivityTracker.Duration(activity.Selected.ActiveSeconds));
                Check(clock.Interval == 1000, "clock and foreground sampling interval is one second");
                form.Render(sample, true, Path.Combine(args[0], "dot-live.png"));
                form.Render(sample, false, Path.Combine(args[0], "dot-window.png"));
                form.Render(sample, true, Path.Combine(args[0], "dot-live.png"));
                var demo = new AppIdentity { ProcessId = 2147483647, Key = "example-only", Name = "CONTOH GAME / PENGINGAT", OpenedUtc = DateTime.UtcNow.AddMinutes(-80) };
                activity.Advance(demo, 0, false); for (int i = 0; i < 3600; i++) activity.Advance(demo, 1, false);
                using (var bitmap = new Bitmap(form.Width, form.Height)) { form.DrawToBitmap(bitmap, new Rectangle(Point.Empty, bitmap.Size)); bitmap.Save(Path.Combine(args[0], "reminder-example.png")); }
                Check(activity.Selected.ReminderDue, "red reminder preview is backed by the actual duration threshold");
                log.AppendLine(((SensorReader)Field(form, "reader")).Report(sample));
                ((SensorReader)Field(form, "reader")).Dispose();
            }
            File.WriteAllText(Path.Combine(args[0], "dot-checks.txt"), log.ToString()); return 0;
        }
        catch (Exception e) { File.WriteAllText(Path.Combine(args[0], "dot-checks.txt"), log + "\n" + e); return 1; }
    }
}
