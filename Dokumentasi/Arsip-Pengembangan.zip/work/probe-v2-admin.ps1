& {
$ErrorActionPreference='Stop'
$a=[Reflection.Assembly]::LoadFrom('C:\Users\Makarim\Documents\Codex\2026-10-11\co\outputs\MiniMonitor\sensors\LibreHardwareMonitorLib.dll')
$c=New-Object LibreHardwareMonitor.Hardware.Computer
$c.IsCpuEnabled=$true
$c.IsGpuEnabled=$true
$c.IsStorageEnabled=$true
try { $c.Open(); foreach($h in $c.Hardware){$h.Update(); Write-Output ($h.HardwareType.ToString()+' | '+$h.Name); $h.Sensors | Where-Object SensorType -eq Temperature | Select-Object Name,Value | Format-Table} } finally {$c.Close()}

} *> 'C:\Users\Makarim\Documents\Codex\2026-10-11\co\work\probe-admin.txt'
