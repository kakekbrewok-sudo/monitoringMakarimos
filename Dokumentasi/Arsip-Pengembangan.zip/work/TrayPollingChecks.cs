using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

static class TrayPollingChecks
{
    static readonly BindingFlags flags = BindingFlags.Instance | BindingFlags.NonPublic;
    static readonly StringBuilder log = new StringBuilder();
    static int clockTicks, sensorTicks;
    [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] static extern IntPtr GetActiveWindow();
    [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    static string Focus()
    {
        uint pid; IntPtr foreground = GetForegroundWindow(); GetWindowThreadProcessId(foreground, out pid);
        return " foreground=" + foreground + " pid=" + pid + " active=" + GetActiveWindow();
    }
    static object Get(object o, string name) { return o.GetType().GetField(name, flags).GetValue(o); }
    static void Set(object o, string name, object value) { o.GetType().GetField(name, flags).SetValue(o, value); }
    static void Call(object o, string name, params object[] args) { o.GetType().GetMethod(name, flags).Invoke(o, args); }
    static void Check(bool ok, string text) { if (!ok) throw new Exception("FAIL: " + text); log.AppendLine("PASS: " + text); }
    static void Click(ToolStripItem item) { typeof(ToolStripItem).GetMethod("HandleClick", flags).Invoke(item, new object[] { EventArgs.Empty }); }
    static async Task HoldTrayMenu(MonitorWindow form, string label, ToolStripMenuItem submenu)
    {
        var tray = (NotifyIcon)Get(form, "tray");
        var menu = (ContextMenuStrip)Get(form, "menu");
        // Use NotifyIcon's actual context-menu entry point, which gives its
        // native notification window foreground ownership (not menu.Show).
        Call(tray, "ShowContextMenu");
        log.AppendLine(label + ": opened" + Focus());
        await Task.Delay(100);
        Check(menu.Visible, label + ": tray context menu opens");
        if (submenu != null) submenu.ShowDropDown();
        int startClock = clockTicks, startSensors = sensorTicks;
        DateTime lastPoll = (DateTime)Get(form, "lastPoll");
        IntPtr windowHandle = form.Handle;
        await Task.Delay(3400);
        Check(clockTicks - startClock >= 3 && sensorTicks - startSensors >= 3 && (DateTime)Get(form, "lastPoll") > lastPoll,
            label + ": real clock and sensor timers keep updating");
        Check(menu.Visible && (submenu == null || submenu.DropDown.Visible), label + ": menu survives multiple live refreshes");
        Check(form.Handle == windowHandle, label + ": window handle remains stable");
        var option = (ToolStripMenuItem)Get(form, submenu == null ? "keepMenuItem" : "clockSoundItem");
        if (submenu != null)
        {
            bool before = option.Checked; Click(option);
            Check(option.Checked != before && menu.Visible && submenu.DropDown.Visible, label + ": delayed click is usable and updates check mark");
            Click(option); // restore muted QA setting
        }
        menu.Close(ToolStripDropDownCloseReason.Keyboard);
        await Task.Delay(100);
        Check(!menu.Visible, label + ": Escape can still dismiss");
    }
    [STAThread] static int Main(string[] args)
    {
        int result = 0;
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
        using (var form = new MonitorWindow(false))
        {
            Set(form, "settingsPath", Path.Combine(args[0], "polling-test-settings.txt"));
            Set(form, "keepMenuOpen", true); Set(form, "clockSound", false); Set(form, "appSound", false);
            Set(form, "pin", true); Set(form, "interval", 1000);
            ((Timer)Get(form, "timer")).Interval = 1000;
            ((Timer)Get(form, "timer")).Tick += (s,e) => sensorTicks++;
            ((Timer)Get(form, "clockTimer")).Tick += (s,e) => clockTicks++;
            form.Location = new Point(Screen.PrimaryScreen.WorkingArea.Right - form.Width - 30, 30);
            ((ContextMenuStrip)Get(form, "menu")).Closed += (s,e) => log.AppendLine("Menu closed: " + e.CloseReason + Focus());
            form.Activated += (s,e) => log.AppendLine("Monitor activated" + Focus());
            form.Shown += async (s,e) =>
            {
                try
                {
                    for (int wait=0; wait<100 && (!(bool)((Timer)Get(form,"timer")).Enabled || (bool)Get(form,"busy")); wait++) await Task.Delay(100);
                    Check(((Timer)Get(form, "timer")).Enabled, "live sensor polling started");
                    await HoldTrayMenu(form, "Pinned window / root", null);
                    var sound = (ToolStripMenuItem)((ToolStripMenuItem)Get(form, "clockSoundItem")).OwnerItem;
                    await HoldTrayMenu(form, "Pinned window / sound submenu", sound);
                    Call(form, "SetOverlay", true); await Task.Delay(200);
                    await HoldTrayMenu(form, "Overlay / sound submenu", sound);
                    form.Hide(); await Task.Delay(100);
                    await HoldTrayMenu(form, "Hidden in tray / sound submenu", sound);
                    Check(!form.Visible, "background refresh does not reshow the hidden overlay");
                    // Even normal click-to-close mode must wait for user input.
                    Set(form, "keepMenuOpen", false);
                    await HoldTrayMenu(form, "Normal menu mode / root", null);
                    var tray = (NotifyIcon)Get(form, "tray"); Call(tray, "ShowContextMenu");
                    sound.ShowDropDown(); Click((ToolStripMenuItem)Get(form, "clockSoundItem"));
                    await Task.Delay(100);
                    Check(!((ContextMenuStrip)Get(form, "menu")).Visible, "normal menu mode closes only after selecting an option");
                }
                catch (Exception ex) { result = 1; log.AppendLine(ex.ToString()); }
                finally { form.Close(); }
            };
            Application.Run(form);
        }
        File.WriteAllText(Path.Combine(args[0], args.Length > 1 ? args[1] : "tray-polling-checks.txt"), log.ToString());
        return result;
    }
}
