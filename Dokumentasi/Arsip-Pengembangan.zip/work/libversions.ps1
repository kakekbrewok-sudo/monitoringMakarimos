$a=[Reflection.Assembly]::ReflectionOnlyLoadFrom('C:\Users\Makarim\Documents\Codex\2026-10-11\co\outputs\MiniMonitor\sensors\DiskInfoToolkit.dll')
$a.GetReferencedAssemblies() | Select-Object Name,Version | Format-Table
